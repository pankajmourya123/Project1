package com.cedge.gscb.mail;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class SendMail {
	public static void getMailProp( String propLoc, String[] toEmail, String[] ccEmail, String[] fromEmail, String[] smtpServer)
    {
        Properties properties = new Properties();
        try {
            File propFile = new File(propLoc);
            FileInputStream fileInput = new FileInputStream(propFile);
            properties.load(fileInput);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        toEmail[0] = properties.getProperty("MailTo");
        ccEmail[0] = properties.getProperty("MailCc");
        fromEmail[0] = properties.getProperty("MailFrom");
        smtpServer[0] = properties.getProperty("MailHost");

    }

}
