package com.cedge.gscb.gateway;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.Properties;

public class ClientDemo {
	
	public static void hitStringToCBS(String requestString, String[] responseString){
		
		try{
			String propFile = "/ServerProp/server.properties";
			Properties properties = new Properties();
			InputStream inputStream1 = ClientDemo.class.getResourceAsStream(propFile);
			properties.load(inputStream1);
			inputStream1.close();
			String cbsServer=properties.getProperty("cbsServer");
			String cbsPort=properties.getProperty("cbsPort");
			int port = Integer.parseInt(cbsPort);
		//	InetAddress address = InetAddress.getByName(cbsServer);
			Socket clientDemo = new Socket(cbsServer, port);
		//	Socket clientDemo = new Socket(address, port);
			clientDemo.setSoTimeout(60000);
			long startTime = System.currentTimeMillis();
		//	logger.debug("Connected to "+ client.getRemoteSocketAddress());
			OutputStream outToServer = clientDemo.getOutputStream();
			DataOutputStream out =new DataOutputStream(outToServer);
			out.writeBytes(requestString+"\n");
			out.flush();
			InputStream inputStream= clientDemo.getInputStream();
			long elapsedTime = System.currentTimeMillis() - startTime;
			InputStreamReader inputStreamReader =new InputStreamReader(inputStream);
			char[] charArray =new char[213];
			int i = inputStreamReader.read(charArray, 0, 213);
			responseString[0]=new String(charArray);
		}
		catch (SocketException e1) {
			String exception1 = e1.toString();
			responseString[0] = new String(exception1);
		}
		catch (IOException e2) {
			String exception2 = e2.toString();
			responseString[0] = new String(exception2);
		}
		catch(Exception e3){
			String excption3 = e3.toString();
			responseString[0] = new String(excption3);	
		}
	}
}
