package com.cedge.mp.neft.recon;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class READ_PROPERTY_FILE {
	public static void getProperties(String propLoc, String key, String[] ftpProvider, String[] fileLoc)
	{	
		Properties properties = new Properties();
		try {
			File propFile = new File(propLoc);
			FileInputStream fileInput = new FileInputStream(propFile);
			properties.load(fileInput);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ftpProvider[0] = properties.getProperty(key+"_FTP");
		fileLoc[0] = properties.getProperty(key+"_NEFT_RECON");	    
	}
	
	public static void getCBSProperties(String propLoc, String key, String[] ftpProvider, String[] fileLoc)
	{	
		Properties properties = new Properties();
		try {
			File propFile = new File(propLoc);
			FileInputStream fileInput = new FileInputStream(propFile);
			properties.load(fileInput);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ftpProvider[0] = properties.getProperty(key+"_FTP");
		fileLoc[0] = properties.getProperty(key+"_RECON_CBS");	    
	}
	
	public static void getMailProp( String propLoc,String[] toEmail, String[] ccEmail,
			String[] fromEmail, String[] smtpServer)
	{	
		Properties properties = new Properties();
		try {
			File propFile = new File(propLoc);
			FileInputStream fileInput = new FileInputStream(propFile);
			properties.load(fileInput);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		toEmail[0] = properties.getProperty("MailTo");
		ccEmail[0] = properties.getProperty("MailCc");
		fromEmail[0] = properties.getProperty("MailFrom");
		smtpServer[0] = properties.getProperty("MailHost");
		
	}

	
}
